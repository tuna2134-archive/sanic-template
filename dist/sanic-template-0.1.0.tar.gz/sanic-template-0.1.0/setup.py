# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['sanic_template']

package_data = \
{'': ['*']}

install_requires = \
['Jinja2>=3.1.2,<4.0.0']

setup_kwargs = {
    'name': 'sanic-template',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'mc_fdc',
    'author_email': 'Masato.04.11.2007@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
